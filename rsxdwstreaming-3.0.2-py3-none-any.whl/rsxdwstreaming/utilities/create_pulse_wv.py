import numpy as np


def complex_to_iqiq(complex_list):
    """Returns a list of I/Q samples from a complex list.
    iqiqiq_list = complex_to_iqiq(complex_list)"""
    def f(iq, i):
        if i == 0:
            return iq.real
        else:
            return iq.imag
    iqiqiq_list = [f(iq, i) for iq in complex_list for i in range(2)]

    return iqiqiq_list


def write_wv(iq_data, f_sampling_rate, file_name):
    """Writes a WV file.
    iqData can be a list of complex or list of floats (iqiqiq format mandatory).
    writtenSamples = WriteWv("MyFile.wv",complexList, fs)"""

    import struct
    from datetime import date
    import math
    import logging

    # check if iqData is complex
    if isinstance(iq_data[0], complex):
        iq_data = complex_to_iqiq(iq_data)

    number_of_samples = len(iq_data) // 2

    # Find maximum magnitude and scale for max to be FullScale (1.0)
    power = []
    for n in range(number_of_samples):
        power.append(abs(iq_data[2 * n] ** 2 + iq_data[2 * n + 1] ** 2))
    scaling = math.sqrt(max(power))

    # normalize to magnitude 1
    iq_data = [iq / scaling for iq in iq_data]

    # calculate rms in dB (below full scale)
    # rms = math.sqrt(sum(power) / number_of_samples) / scaling
    # rms = abs(20 * math.log10(rms))
    # Convert to int16, use floor function, otherwise distribution is not correct
    iq_data = [math.floor(iq * 32767 + .5) for iq in iq_data]

    try:
        file = open(file_name, "wb")

        file.write("{TYPE: SMU-WV,0}".encode("ASCII"))
        file.write("{COMMENT: R&S WaveForm, TheAE-RA}".encode("ASCII"))
        file.write(("{DATE: " + str(date.today()) + "}").encode("ASCII"))
        file.write(("{CLOCK:" + str(f_sampling_rate) + "}").encode("ASCII"))
        file.write("{LEVEL OFFS:0,0}".encode("ASCII"))
        file.write(("{SAMPLES:" + str(number_of_samples) + "}").encode("ASCII"))
        # TODO: markers
        #     if( m1start > 0 && m1stop > 0)
        #        %Control Length only needed for markers
        #        fprintf(file_id,'%s',['{CONTROL LENGTH:' num2str(data_length) '}']);
        #        fprintf(file_id,'%s',['{CLOCK MARKER:' num2str(fSamplingRate) '}']);
        #        fprintf(file_id,'%s',['{MARKER LIST 1: ' num2str(m1start) ':1;' num2str(m1stop) ':0}']);
        #    end
        file.write(("{WAVEFORM-" + str(4 * number_of_samples + 1) + ": #").encode("ASCII"))

        # binary block
        file.write(struct.pack("h" * len(iq_data), *iq_data))

        file.write("}".encode("ASCII"))

        file.close()

    except IOError:
        logging.error("File (" + file_name + ") write error!")

    return number_of_samples


if __name__ == "__main__":
    iq = np.ones(240000)
    iq[60000:] = 0

    t = np.linspace(0, 100e-6, 240000)

    # iq = iq * np.exp(1j*2*np.pi*1e9*t)

    write_wv(iq, 2.4e9, '../examples/pulse2.wv')
