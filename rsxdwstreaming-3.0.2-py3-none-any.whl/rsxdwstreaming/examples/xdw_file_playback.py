"""XDW File Playback Module

This module provides classes for creating XDW file playback scenarios. It enables generation
of pulse sequence definition (.ps_def), waveform container (.wv), and address lookup (.ps_adr)
files that can be used for offline playback on Rohde & Schwarz signal generators.

The main workflow:
    1. Create an XdwFilePlayback instance with a filename
    2. Append XDW entries (PDWs/TCDWs) with optional ARB segments
    3. Generate the output files for playback

Example:
    .. code-block:: python

        from rsxdwstreaming.examples.xdw_file_playback import XdwFilePlayback
        from rsxdwstreaming import pdw_expert, ctrl_xdw, xdw_payload

        # Create file playback instance
        file_playback = XdwFilePlayback('IQ_expert')

        # Add PDW with ARB segment
        pdw1 = pdw_expert.PdwExpert(toa=0, payload=xdw_payload.XdwPayloadSegmentArb(segment_idx=0))
        file_playback.append_entry(pdw1, 'pulse1.wv')

        # Add control descriptor word
        cdw1 = ctrl_xdw.TcdwExpert(toa=1e-3, path=0, list_idx=1, cmd=ctrl_xdw.CtrlXdwCmd.LIST_IDX)
        file_playback.append_entry(cdw1)

        # Generate output files
        file_playback.generate_files()
"""
from rsxdwstreaming import pdw_expert, ctrl_xdw, xdw_payload
from datetime import datetime
from rskfd.iq_data_handling import iqdata
from rsxdwstreaming.utilities.create_pulse_wv import write_wv
import typing


class XdwList:
    """Pulse sequence definition list

    This class manages the pulse sequence definition header and collects XDW (PDW/TCDW) entries.
    It generates the .ps_def file which contains metadata and the raw XDW data.

    :param filename: Base filename for the pulse sequence definition (without extension)
    """
    def __init__(self, filename: str = 'IQ'):
        self.filename = filename
        self.b = bytearray()
        self.b_pdw_raw = bytearray()

        self.init_bytearray()

    def init_bytearray(self):
        """Initialize the pulse sequence definition header

        Creates the header structure including format identifier, stream settings,
        filenames for waveform and address files, timestamp, and reserved fields.
        """
        self.b.extend('PDW'.encode())
        self.b.extend([0])  # stream ID
        self.b.extend([0])  # target ID, baseband index
        # self.b.extend([int('12', 16)])  # version & sysclock
        self.b.extend([0])  # version & sysclock
        self.b.extend([0])  # skip segments

        wv_name = f'{self.filename}.wv'.encode()
        self.b.extend(wv_name)
        self.b.extend([0] * (256 - len(wv_name)))

        adr_name = f'{self.filename}.ps_adr'.encode()
        self.b.extend(adr_name)
        self.b.extend([0] * (256 - len(adr_name)))

        # write date and time
        now = datetime.now()
        now_enc = now.strftime('%d.%m.%Y %H:%M').encode()
        self.b.extend(now_enc)
        self.b.extend([0] * (64 - len(now_enc)))

        # comment
        comment_name = 'python generated'.encode()
        self.b.extend(comment_name)
        self.b.extend([0] * (256 - len(comment_name)))

        # self.b.extend(np.uint32(0).byteswap())  # bandwidth
        # self.b.extend(np.uint64(1).byteswap())  # nof PDWs
        # self.b.extend([255] * (256 - 12))  # reserved
        self.b.extend([255] * 256)  # reserved

    def append_xdw(self, pdw):
        """Append an XDW (PDW or TCDW) to the raw data buffer

        :param pdw: Pulse or control descriptor word to append
        :type pdw: PdwBasic, PdwExpert, TcdwBasic, or TcdwExpert
        """
        # add PDWs
        self.b_pdw_raw += pdw.get_xdw()

    def write_ps_def(self):
        """Write the pulse sequence definition file

        Combines the header and raw XDW data into a .ps_def file.
        The filename is taken from the instance's filename attribute.

        :raises IOError: If file cannot be written
        """
        """filename shall be absolute path"""
        ps_def = open(f'{self.filename}.ps_def', "wb")
        ps_def.write(self.b)
        ps_def.write(bytes(self.b_pdw_raw))
        ps_def.close()


class ContainerWv:
    """Waveform container for ARB segments

    This class collects IQ data from multiple waveform files and manages them in a single
    container. It generates the .wv file containing all concatenated waveform segments.

    :param filename: Base filename for the waveform container (without extension)
    """
    def __init__(self, filename: str = 'IQ'):
        self.filename = filename
        self.filename_list: typing.List = []
        self.iqdata: typing.List = []
        self.num_elements = 0
        self.sampling_rate: float = 0.0

    def append_wv(self, new_iq, segment_name):
        """Append a waveform segment to the container

        :param new_iq: IQ data samples to append
        :type new_iq: list of complex
        :param segment_name: Name/identifier of the waveform segment
        :type segment_name: str
        """
        self.iqdata.extend(new_iq)
        self.filename_list.append(segment_name)
        self.num_elements += 1

    def write_container_wv(self):
        """Write the waveform container file

        Creates a .wv file containing all collected IQ data samples using the
        sampling rate from the first loaded waveform.

        :raises IOError: If file cannot be written
        """
        if not self.iqdata:
            self.append_wv([1+0j], 'empty_segment')     # add CW segment if no data is present to avoid errors in file writing
            self.sampling_rate = 2.4e9                  # set default sampling rate for CW segment
        write_wv(self.iqdata, self.sampling_rate, f'{self.filename}.wv')


class LookUp:
    """Address lookup table for waveform segments

    This class manages the address lookup table (.ps_adr file) that maps segment indices
    to their start and stop addresses in the waveform container. This allows the signal
    generator to locate specific waveform segments during playback.

    :param filename: Base filename for the address lookup file (without extension)
    """
    def __init__(self, filename):
        self.filename = filename
        self.next_start_bit = 0
        self.seg_samples_bits = 0
        self.b = bytearray()
        self.init_look_up()

    def init_look_up(self):
        """Initialize the address lookup table header

        Creates the header structure with format identifier ('ADR'), version,
        and reserved fields.
        """
        self.b.extend('ADR'.encode())
        self.b.extend([1])  # version & sysclock
        self.b.extend(int(2).to_bytes(4, 'little'))  # rsvd
        self.b.extend(int(3).to_bytes(4, 'little'))  # rsvd
        self.b.extend(int(4).to_bytes(4, 'little'))  # rsvd
        self.b.extend(int(5).to_bytes(4, 'little'))  # rsvd
        self.b.extend(int(6).to_bytes(4, 'little'))  # rsvd
        self.b.extend(int(7).to_bytes(4, 'little'))  # rsvd
        self.b.extend(int(8).to_bytes(4, 'little'))  # rsvd

    def write_ps_adr(self):
        """Write the address lookup file

        Creates the .ps_adr file containing the header and all segment
        address entries.

        :raises IOError: If file cannot be written
        """
        """filename shall be absolute path"""
        ps_adr = open(f'{self.filename}.ps_adr', "wb")
        ps_adr.write(self.b)
        ps_adr.close()

    def add_address(self, segment_length):
        """Add an address entry for a waveform segment

        Calculates and stores the start and stop bit addresses for a waveform segment,
        including proper padding to meet alignment requirements (256-bit boundaries).

        :param segment_length: Number of IQ samples in the segment
        :type segment_length: int
        """
        new_address = bytearray()
        start_address = self.next_start_bit
        self.seg_samples_bits += segment_length * 4 * 8  # 4 bytes per sample, 8 bits per byte
        pad_bits = (32 - (segment_length % 32)) % 32
        stop_address = self.seg_samples_bits - 1
        new_address.extend((start_address << 4).to_bytes(5, 'big'))
        new_address.extend((stop_address << 4).to_bytes(5, 'big'))
        new_address.extend(int(0).to_bytes(6, 'big'))

        self.seg_samples_bits += pad_bits
        self.next_start_bit = stop_address + 1
        self.b.extend(new_address)


class XdwFilePlayback:
    """Main class for XDW file playback scenario generation

    This class orchestrates the creation of complete file playback scenarios by managing
    XDW lists, waveform containers, and address lookup tables. It provides a high-level
    interface for appending PDWs/TCDWs with optional ARB segments and generating all
    required output files.

    :param filename: Base filename for all generated files (without extensions)

    :ivar xdw_list: Pulse sequence definition list manager
    :vartype xdw_list: XdwList
    :ivar container_wv: Waveform container manager
    :vartype container_wv: ContainerWv
    :ivar look_up: Address lookup table manager
    :vartype look_up: LookUp

    Example:
        .. code-block:: python

            # Create file playback instance
            playback = XdwFilePlayback('my_scenario')

            # Add PDW with ARB waveform
            pdw = pdw_expert.PdwExpert(toa=0, payload=xdw_payload.XdwPayloadSegmentArb(segment_idx=0))
            playback.append_entry(pdw, 'pulse.wv')

            # Generate files: my_scenario.ps_def, my_scenario.wv, my_scenario.ps_adr
            playback.generate_files()
    """
    def __init__(self, filename: str = ''):
        self.filename = filename
        self.xdw_list = XdwList(filename)
        self.container_wv = ContainerWv(filename)
        self.look_up = LookUp(filename)

    def append_entry(self, new_xdw, arb_segment: str = ''):
        """Append an XDW entry with optional ARB segment to the playback scenario

        This method adds a PDW or TCDW to the sequence. If an ARB segment is specified,
        the waveform is loaded, added to the container, and the address lookup table is
        updated. The segment index in the PDW payload is automatically set.

        :param new_xdw: Pulse or control descriptor word to append
        :type new_xdw: PdwBasic, PdwExpert, TcdwBasic, or TcdwExpert
        :param arb_segment: Optional path to waveform file (.wv) for ARB segments
        :type arb_segment: str

        .. note::
            - ARB segments are only processed if the payload type is XdwPayloadSegmentArb
            - Duplicate waveform files are automatically detected and reused
            - Waveforms are zero-padded to meet alignment requirements
        """
        if arb_segment and (new_xdw.payload.__class__ == xdw_payload.XdwPayloadSegmentArb):
            if arb_segment not in self.container_wv.filename_list:
                result = iqdata.ReadWv(arb_segment)
                if result is not None and len(result) == 2:
                    new_iq, sampling_rate = result
                    self.container_wv.sampling_rate = float(sampling_rate)
                else:
                    raise ValueError(f"Unexpected return value from ReadWv for file: {arb_segment}")
                # this zero padding is to assure that the stop address fulfills the condition (n*256) - 1
                if len(new_iq) % 8:
                    pad_bits = 8 - (len(new_iq) % 8)
                    new_iq.extend(pad_bits * [0+0j])
                # add iq samples before zero padding, so that stop address is not including zeros
                self.look_up.add_address(len(new_iq))
                if len(new_iq) % 128:
                    pad_bits = 128 - (len(new_iq) % 128)
                    new_iq.extend(pad_bits * [0+0j])
                self.container_wv.append_wv(new_iq, arb_segment)
            idx = self.container_wv.num_elements - 1  # TODO: return correct index
            new_xdw.payload.segment_idx = idx
        self.xdw_list.append_xdw(new_xdw)

    def generate_files(self):
        """Generate all output files for playback

        Creates the following files using the instance's filename:
            - <filename>.ps_def: Pulse sequence definition with XDW entries
            - <filename>.ps_adr: Address lookup table for waveform segments
            - <filename>.wv: Waveform container with IQ data

        These files can be loaded into a Rohde & Schwarz signal generator
        for offline playback of the defined pulse scenario.

        :raises IOError: If any file cannot be written
        """
        self.xdw_list.write_ps_def()
        self.look_up.write_ps_adr()
        self.container_wv.write_container_wv()


if __name__ == "__main__":
    file_playback = XdwFilePlayback('IQ_expert')
    arb_file1 = 'pulse1.wv'
    pdw1 = pdw_expert.PdwExpert(toa=0, payload=xdw_payload.XdwPayloadSegmentArb(segment_idx=0))
    file_playback.append_entry(pdw1, arb_file1)

    cdw1 = ctrl_xdw.TcdwExpert(toa=1e-3, path=0, list_idx=1, cmd=ctrl_xdw.CtrlXdwCmd.LIST_IDX)
    file_playback.append_entry(cdw1)

    arb_file2 = 'pulse2.wv'
    pdw3 = pdw_expert.PdwExpert(toa=2, payload=xdw_payload.XdwPayloadSegmentArb(segment_idx=0))
    file_playback.append_entry(pdw3, arb_file2)

    cdw1 = ctrl_xdw.TcdwExpert(toa=4, path=0, list_idx=0, cmd=ctrl_xdw.CtrlXdwCmd.LIST_IDX)
    file_playback.append_entry(cdw1)

    pdw1 = pdw_expert.PdwExpert(toa=6, payload=xdw_payload.XdwPayloadSegmentArb(segment_idx=0))
    file_playback.append_entry(pdw1, arb_file1)

    cdw1 = ctrl_xdw.TcdwExpert(toa=8, path=0, list_idx=1, cmd=ctrl_xdw.CtrlXdwCmd.LIST_IDX)
    file_playback.append_entry(cdw1)

    pdw3 = pdw_expert.PdwExpert(toa=10, payload=xdw_payload.XdwPayloadSegmentArb(segment_idx=0))
    file_playback.append_entry(pdw3, arb_file2)

    cdw_end = ctrl_xdw.TcdwExpert(toa=12, path=0, cmd=ctrl_xdw.CtrlXdwCmd.EOF)
    file_playback.append_entry(cdw_end)

    file_playback.generate_files()
