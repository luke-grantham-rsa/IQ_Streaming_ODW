# pylint: skip-file
import bitstring
from .xdw import Xdw
from .xdw_format import XdwFormat
from .xdw_payload import OdwPayloadEmpty


class Odw(Xdw):
    """Metadata descriptor word (ODW) class

    :param payload: ODW payload
    :keyword ignore_xdw: Flag to determine if ODW is ignored
    :type ignore_xdw: bool
    :keyword m1: Marker 1
    :keyword m2: Marker 2
    :keyword m3: Marker 3
    :keyword freq_offset: Frequency offset in Hertz
    :keyword level_offset: Level offset in dB
    :keyword phase_offset: Phase offset in degree

    """

    def __init__(self, **kwargs):
        self.phase_mod = 0
        super().__init__(xdw_format=XdwFormat.ODW_BASIC, payload=OdwPayloadEmpty,
                         not_allowed_keys=['phase_mod'], **kwargs)

    def create_xdw_header(self):
        """Assemble basic ODW header and write to member variable
        """
        toa_ticks = round(self.toa * 2.4e9)

        bs_packed = bitstring.pack('uint:52, uint:1, uint:1, uint:2',
                                   toa_ticks, 0, 0, 0)
        self.b_xdw_header = bs_packed.bytes

    def get_xdw(self):
        """Assemble basic ODW from header, flags, body and payload

        :return: Raw expert ODW
        :rtype: Bytes Object

        """
        self.create_xdw_payload()
        self.create_xdw_header()
        self.create_xdw_flags()
        self.create_xdw_body()
        odw_params = bytes(4)

        return self.b_xdw_header + self.b_xdw_flags + self.b_xdw_body + odw_params + self.b_xdw_payload
